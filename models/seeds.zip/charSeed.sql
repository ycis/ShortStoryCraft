USE storydb;

INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Mary', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Patricia', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Linda', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Barbara', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Elizabeth', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jennifer', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Maria', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Susan', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Margaret', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Dorothy', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lisa', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Nancy', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Karen', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Betty', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Helen', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sandra', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Donna', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Carol', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ruth', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sharon', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Michelle', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Laura', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sarah', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kimberly', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Deborah', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jessica', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Shirley', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Cynthia', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Angela', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Melissa', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Brenda', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Amy', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Anna', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Rebecca', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Virginia', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kathleen', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Pamela', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Martha', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Debra', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Amanda', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Stephanie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Carolyn', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Christine', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Marie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Janet', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Catherine', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Frances', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ann', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Joyce', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Diane', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Alice', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Julie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Heather', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Teresa', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Doris', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Gloria', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Evelyn', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Cheryl', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Mildred', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Katherine', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Joan', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ashley', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Judith', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Rose', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Janice', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Nicole', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Judy', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Christina', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kathy', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Theresa', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Beverly', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Denise', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Tammy', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Irene', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jane', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lori', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Rachel', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Marilyn', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Andrea', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kathryn', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Louise', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sara', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Anne', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jacqueline', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Wanda', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Bonnie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Julia', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ruby', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lois', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Tina', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Phyllis', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Norma', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Paula', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Diana', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Annie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lillian', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Emily', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Peggy', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Crystal', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Gladys', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Rita', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Dawn', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Connie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Florence', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Edna', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Tiffany', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Carmen', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Rosa', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Cindy', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Grace', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Wendy', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Victoria', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Edith', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sherry', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sylvia', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Josephine', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Thelma', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sheila', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ethel', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ellen', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Elaine', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Marjorie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Carrie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Charlotte', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Monica', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Esther', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Pauline', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Emma', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Juanita', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Anita', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Rhonda', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Hazel', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Amber', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Eva', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Debbie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('April', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Clara', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lucille', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Joanne', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Eleanor', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Valerie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Danielle', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Megan', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Alicia', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Suzanne', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Michele', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Gail', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Bertha', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Darlene', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Veronica', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jill', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Erin', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Geraldine', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lauren', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Cathy', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Joann', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lorraine', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sally', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Regina', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Erica', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Beatrice', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Dolores', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Bernice', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Audrey', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Yvonne', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Annette', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('June', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Samantha', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Stacy', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ana', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Renee', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ida', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Vivian', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Roberta', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Holly', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Brittany', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Melanie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Loretta', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Yolanda', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jeanette', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Laurie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Katie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kristen', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Vanessa', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Alma', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sue', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Elsie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Beth', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jeanne', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Vicki', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Carla', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Tara', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Rosemary', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Eileen', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Terri', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Gertrude', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lucy', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Tonya', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ella', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Stacey', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Wilma', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Gina', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kristin', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Natalie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Agnes', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Vera', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Charlene', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Bessie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Delores', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Melinda', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Pearl', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Arlene', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Maureen', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Colleen', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Allison', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Tamara', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Joy', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Georgia', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Constance', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lillie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Claudia', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Marcia', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Tanya', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Nellie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Minnie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Marlene', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Heidi', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Glenda', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lydia', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Viola', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Marian', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Stella', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Caroline', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Dora', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jo', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Vickie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Mattie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Maxine', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Irma', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Mabel', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Marsha', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Myrtle', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lena', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Christy', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Deanna', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Patsy', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Hilda', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Gwendolyn', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jennie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Nora', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Margie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Nina', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Cassandra', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Leah', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Penny', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kay', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Priscilla', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Naomi', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Carole', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Brandy', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Olga', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Billie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Dianne', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Tracey', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Leona', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jenny', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Felicia', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sonia', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Miriam', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Velma', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Becky', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Bobbie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Violet', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kristina', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Toni', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Misty', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Mae', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Shelly', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Daisy', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ramona', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sherri', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Erika', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Katrina', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Claire', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lindsey', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lindsay', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Geneva', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Belinda', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Margarita', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sheryl', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Cora', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Faye', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ada', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Natasha', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sabrina', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Isabel', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Marguerite', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Hattie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Harriet', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Molly', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Cecilia', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kristi', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Brandi', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Blanche', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sandy', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Rosie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Joanna', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Iris', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Eunice', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Eunice', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Angie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Inez', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lynda', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Madeline', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Amelia', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Alberta', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Genevieve', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Monique', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jodi', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Janie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Maggie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kayla', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sonya', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kristine', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Candace', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Fannie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Maryann', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Opal', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Alison', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Yvette', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Melody', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Luz', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Susie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Olivia', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Flora', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Shelley', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kristy', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Mamie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lula', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lola', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Verna', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Beulah', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Antoinette', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Candice', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Juana', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jeannette', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Pam', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kelli', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Hannah', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Whitney', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Bridget', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Karla', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Celia', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Latoya', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Patty', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Shelia', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Gayle', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Della', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Vicky', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lynne', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sheri', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Marianne', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kara', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jacquelyn', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Erma', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Blanca', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Myra', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Leticia', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Krista', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Roxanne', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Angelica', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Robyn', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Adrienne', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Rosalie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Alexandra', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Brooke', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Bethany', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sadie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Bernadette', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Traci', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kendra', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jasmine', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Nichole', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Rachael', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Chelsea', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Mable', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ernestine', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Muriel', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Marcella', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Elena', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Krystal', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Angelina', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Nadine', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kari', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Estelle', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Dianna', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Paulette', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lora', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Mona', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Doreen', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Rosemarie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Desiree', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Antonia', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Hope', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ginger', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Janis', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Betsy', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Christie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Freda', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Mercedes', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Meredith', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lynette', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Teri', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Cristina', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Eula', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Leigh', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Meghan', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sophia', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Eloise', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Rochelle', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Gretchen', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Cecelia', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Raquel', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Henrietta', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Alyssa', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jana', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kelley', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Gwen', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jenna', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Tricia', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Laverne', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Olive', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Alexis', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Tasha', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Silvia', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Elvira', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Delia', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sophie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kate', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Patti', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lorena', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kellie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sonja', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lila', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lana', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Darla', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('May', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Mindy', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Essie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Mandy', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lorene', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Elsa', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Josefina', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jeannie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Miranda', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Dixie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lucia', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Marta', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Faith', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lela', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Johanna', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Shari', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Camille', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Tami', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Shawna', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Elisa', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ebony', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Melba', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ora', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Nettie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Tabitha', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ollie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Winifred', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kristie', 'her',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('James', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('John', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Robert', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Michael', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('William', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('David', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Richard', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Charles', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Joseph', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Thomas', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Christopher', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Daniel', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Paul', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Mark', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Donald', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('George', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kenneth', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Steven', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Edward', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Brian', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ronald', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Anthony', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kevin', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jason', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Matthew', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Gary', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Timothy', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jose', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Larry', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jeffrey', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Frank', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Scott', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Eric', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Stephen', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Andrew', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Raymond', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Gregory', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Joshua', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jerry', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Dennis', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Walter', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Patrick', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Peter', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Harold', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Douglas', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Henry', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Carl', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Arthur', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ryan', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Roger', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Joe', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Juan', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jack', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Albert', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jonathan', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Justin', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Gerald', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Keith', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Samuel', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ralph', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lawrence', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Nicholas', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Roy', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Benjamin', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Bruce', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Brandon', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Adam', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Harry', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Fred', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Wayne', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Billy', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Steve', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Louis', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jeremy', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Aaron', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Randy', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Howard', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Eugene', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Carlos', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Russell', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Bobby', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Victor', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Martin', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ernest', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Phillip', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Todd', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jesse', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Craig', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Alan', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Shawn', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Clarence', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sean', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Philip', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Chris', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Johnny', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Earl', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jimmy', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Antonio', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Danny', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Bryan', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Tony', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Luis', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Mike', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Stanley', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Leonard', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Nathan', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Dale', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Manuel', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Rodney', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Curtis', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Norman', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Allen', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Marvin', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Vincent', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Glenn', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jeffery', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Travis', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jeff', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Chad', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jacob', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Melvin', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Alfred', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kyle', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Bradley', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jesus', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Herbert', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Frederick', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ray', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Joel', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Edwin', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Don', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Eddie', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ricky', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Troy', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Randall', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Barry', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Alexander', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Bernard', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Mario', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Leroy', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Francisco', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Marcus', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Micheal', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Theodore', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Clifford', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Miguel', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Oscar', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jay', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jim', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Tom', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Calvin', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Alex', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jon', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ronnie', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Bill', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lloyd', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Tommy', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Leon', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Derek', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Warren', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Darrell', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jerome', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Floyd', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Leo', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Alvin', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Tim', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Wesley', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Gordon', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Dean', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Greg', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jorge', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Dustin', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Pedro', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Derrick', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Dan', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lewis', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Zachary', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Corey', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Herman', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Maurice', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Vernon', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Roberto', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Clyde', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Glen', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Hector', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Shane', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ricardo', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sam', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Rick', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lester', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Brent', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ramon', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Charlie', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Tyler', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Gilbert', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Gene', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Marc', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Reginald', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ruben', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Brett', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Nathaniel', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Rafael', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Edgar', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Milton', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Raul', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ben', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Chester', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Cecil', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Duane', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Franklin', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Andre', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Elmer', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Brad', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Gabriel', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ron', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Mitchell', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Roland', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Arnold', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Harvey', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jared', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Adrian', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Karl', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Cory', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Claude', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Erik', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Darryl', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Neil', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Christian', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Javier', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Fernando', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Clinton', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ted', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Mathew', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Tyrone', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Darren', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lonnie', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lance', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Cody', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Julio', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kurt', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Allan', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Nelson', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Guy', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Clayton', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Hugh', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Max', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Dwayne', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Dwight', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Armando', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Felix', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jimmie', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Everett', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jordan', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ian', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Wallace', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ken', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Bob', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Alfredo', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Alberto', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Dave', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ivan', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sidney', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Byron', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Julian', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Isaac', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Morris', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Clifton', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Willard', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Daryl', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ross', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Virgil', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Andy', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Marshall', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Salvador', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Perry', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kirk', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sergio', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Seth', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kent', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Terrance', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Rene', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Eduardo', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Terrence', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Enrique', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Freddie', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Wade', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Austin', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Stuart', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Fredrick', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Arturo', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Alejandro', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Joey', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Nick', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Luther', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Wendell', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jeremiah', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Evan', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Julius', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Donnie', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Otis', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Trevor', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Oliver', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Luke', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Homer', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Gerard', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Doug', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kenny', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Hubert', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Angelo', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Shaun', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lyle', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Matt', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Alfonso', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Orlando', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Rex', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Carlton', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ernesto', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Cameron', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Neal', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Pablo', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lorenzo', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Omar', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Wilbur', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Blake', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Grant', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Horace', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Roderick', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Abraham', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Willis', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Rickey', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ira', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Andres', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Cesar', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Johnathan', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Malcolm', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Rudolph', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Damon', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kelvin', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Rudy', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Preston', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Alton', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Archie', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Marco', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Wm', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Pete', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Randolph', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Garry', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Geoffrey', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jonathon', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Felipe', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Bennie', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Gerardo', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ed', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Dominic', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Loren', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Delbert', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Colin', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Guillermo', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Earnest', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lucas', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Benny', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Noel', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Spencer', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Rodolfo', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Myron', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Edmund', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Garrett', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Salvatore', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Cedric', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lowell', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Gregg', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sherman', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Wilson', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Devin', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sylvester', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Roosevelt', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Israel', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jermaine', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Forrest', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Wilbert', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Leland', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Simon', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Clark', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Irving', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Carroll', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Bryant', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Owen', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Rufus', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Woodrow', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sammy', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Kristopher', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Mack', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Levi', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Marcos', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Gustavo', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jake', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lionel', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Marty', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Taylor', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ellis', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Dallas', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Gilberto', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Clint', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Nicolas', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Laurence', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ismael', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Orville', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Drew', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ervin', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Dewey', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Al', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Wilfred', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Josh', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Hugo', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ignacio', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Caleb', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Tomas', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Sheldon', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Erick', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Frankie', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Stewart', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Doyle', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Darrel', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Rogelio', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Terence', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Santiago', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Alonzo', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Elias', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Bert', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Elbert', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Ramiro', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Conrad', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Noah', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Grady', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Phil', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Cornelius', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Lamar', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Rolando', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Clay', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Percy', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Dexter', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Bradford', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Merle', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Darin', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Amos', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Terrell', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Moses', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Irvin', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Saul', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Roman', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Darnell', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Randal', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Tommie', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Timmy', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Darrin', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Winston', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Brendan', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Toby', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Van', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Abel', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Dominick', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Boyd', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Emilio', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Elijah', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Cary', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Domingo', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Santos', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Aubrey', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Emmett', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Marlon', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Emanuel', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Jerald', 'him',sysdate(),sysdate());
INSERT INTO characters (text, alt_text,createdAt,updatedAt)
VALUES ('Edmond', 'him',sysdate(),sysdate());